package co.edureka.tmdb.movieappedureka;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import retrofit.Callback;
import retrofit.RequestInterceptor;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by M1031329 on 4/18/2017.
 */

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);
        String movieId = getIntent().getExtras().getString("movieId");

        getMovieDetails(Integer.parseInt(movieId));

    }

    private void getMovieDetails(Integer movieId) {

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint("https://api.themoviedb.org/3")
                .setRequestInterceptor(new RequestInterceptor() {
                    @Override
                    public void intercept(RequestFacade request) {
                        request.addEncodedQueryParam("api_key", "55957fcf3ba81b137f8fc01ac5a31fb5");
                    }
                })
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        TMDPApi service = restAdapter.create(TMDPApi.class);
        service.getMovieDetails(movieId, new Callback<MovieDetailResult>() {

            @Override
            public void success(MovieDetailResult movieResult, Response response) {

                ImageView item_image =  (ImageView)findViewById(R.id.item_image);
                Picasso.with(DetailsActivity.this)
                        .load(movieResult.getPosterPath())
                        .placeholder(R.color.colorAccent)
                        .into(item_image);

                TextView movieTitle = (TextView) findViewById(R.id.item_text);
                movieTitle.setText(movieResult.getTitle());

                TextView movieReleaseDate = (TextView) findViewById(R.id.text_pratiotioner_group_name);
                movieReleaseDate.setText(movieResult.getReleaseDate());
            }

            @Override
            public void failure(RetrofitError error) {
                error.printStackTrace();
            }
        });
    }
}
